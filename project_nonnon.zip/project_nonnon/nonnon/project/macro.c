// Project Nonnon Shared Macro
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_PROJECT_MACRO
#define _H_NONNON_PROJECT_MACRO




#ifdef _H_NONNON_WIN32_COM_ISHELLLINK

void
n_project_shortcut( n_posix_char *name, n_posix_char *args, int icon_number )
{

	n_posix_char *path = n_win_exepath_new();
//n_posix_debug_literal( "%s", path );

	n_posix_char *dir = n_string_path_upperfolder_new( path );
	n_posix_char *lnk = n_string_path_make_new( dir, name );
//n_posix_debug_literal( "%s\n%s\n%s\n%s", name, path, dir, lnk );

	n_IShellLink_path2lnk( lnk, path, args, path, icon_number );

	n_string_free( path );
	n_string_free( dir  );
	n_string_free( lnk  );


	return;
}

#endif // #ifdef _H_NONNON_WIN32_COM_ISHELLLINK




#ifdef _H_NONNON_NEUTRAL_POSIX


#define n_bool  BOOL
#define n_false FALSE
#define n_true  TRUE




#define n_project_string_drophere   n_posix_literal( "Drop Here" )
#define n_project_string_error      n_posix_literal( "Please Check" )
#define n_project_string_overwrite  n_posix_literal( "Overwrite?" )
#define n_project_string_pleasewait n_posix_literal( "Please Wait..." )
#define n_project_string_really_ok  n_posix_literal( "Really OK?" )
#define n_project_string_go         n_posix_literal( "Go!" )
#define n_project_string_info       n_posix_literal( "INFO" )

void
n_project_dialog_error( HWND hwnd, const n_posix_char *str )
{

	int mb = MB_TOPMOST | MB_ICONERROR | MB_OK;

	MessageBox( hwnd, str, n_project_string_info, mb );

	return;
}

void
n_project_dialog_info( HWND hwnd, const n_posix_char *str )
{

	int mb = MB_TOPMOST | MB_ICONINFORMATION | MB_OK;

	MessageBox( hwnd, str, n_project_string_info, mb );

	return;
}

n_bool
n_project_dialog_yesno( HWND hwnd, const n_posix_char *str )
{

	int mb = MB_TOPMOST | MB_ICONINFORMATION | MB_YESNO;

	int ret = MessageBox( hwnd, str, n_project_string_info, mb );

	return ( ret == IDYES );
}


#endif // #ifdef _H_NONNON_NEUTRAL_POSIX




#ifdef _H_NONNON_NEUTRAL_INI


#define n_project_ini_name n_posix_literal( "./nonnon_win.ini" )


#endif // #ifdef _H_NONNON_NEUTRA_INI




#ifdef _H_NONNON_WIN32_GDI


#define n_project_stdfont() n_gdi_font_find( n_posix_literal( "Trebuchet MS" ), n_posix_literal( "Arial" ) )


#endif // #ifdef _H_NONNON_WIN32_GDI




#ifdef _H_NONNON_WIN32_REGISTRY


#define n_project_startup_register(   l, r ) n_project_startup_register_main( l,    r, n_true  ) 
#define n_project_startup_unregister( l    ) n_project_startup_register_main( l, NULL, n_false ) 

void
n_project_startup_register_main( const n_posix_char *lval, const n_posix_char *rval, n_bool is_reg )
{

	HKEY hive = HKEY_CURRENT_USER;

	const n_posix_char *subkey = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Run" );


	if ( is_reg )
	{

		DWORD byte = n_posix_strlen( rval ) * sizeof( n_posix_char );
//n_posix_debug_literal( "%s\n%s", lval, rval );

		n_registry_write( hive, subkey, lval, REG_SZ, rval, byte );

	} else {

		n_registry_delete_value( hive, subkey, lval );

	}


	return;
}


#endif // #ifdef _H_NONNON_WIN32_REGISTRY




#ifdef _H_NONNON_WIN32_WIN


#define WINDOW          N_WIN_GUI_WINDOW

#define BUTTON          N_WIN_GUI_BUTTON
#define FLATBUTTON      N_WIN_GUI_FLATBUTTON
#define ICONBUTTON      N_WIN_GUI_ICONBUTTON
#define FLATICONBUTTON  N_WIN_GUI_FLATICONBUTTON
#define CHECK           N_WIN_GUI_CHECK
#define ICONCHECK       N_WIN_GUI_ICONCHECK
#define RADIO           N_WIN_GUI_RADIO
#define ICONRADIO       N_WIN_GUI_ICONRADIO
#define GROUP           N_WIN_GUI_GROUP

#define COMBO           N_WIN_GUI_COMBO

#define N_INPUT         N_WIN_GUI_INPUT // [x] : conflict with INPUT structure
#define EDITOR          N_WIN_GUI_EDITOR

#define LIST            N_WIN_GUI_LIST

#define HSCROLL         N_WIN_GUI_HSCROLL
#define VSCROLL         N_WIN_GUI_VSCROLL

#define CANVAS          N_WIN_GUI_CANVAS
#define CANVAS_BUTTON   N_WIN_GUI_CANVAS_BUTTON
#define LABEL           N_WIN_GUI_LABEL
#define STATIC          N_WIN_GUI_STATIC


#define FBTN            FLATBUTTON
#define ICOBTN          ICONBUTTON
#define FICOBTN         FLATICONBUTTON




#define N_WS_POPUPWINDOW ( WS_POPUP | WS_CAPTION | WS_SYSMENU )
#define N_WS_FIXEDWINDOW ( N_WS_POPUPWINDOW | WS_MINIMIZEBOX )

void
n_project_window_resizable( HWND hwnd )
{

	DWORD style = WS_OVERLAPPEDWINDOW;

	// [x] : Win10 build 10041 : buggy : M$ have to fix this problem
	//
	//	below code disables resizing
	//
	//	patched : 2015/03/27 : see n_win_set()
	//	fixed   : 2015/03/28 : search with "n_project_window_resizable" and see n_*_resize()

	//if ( n_sysinfo_version_10_or_later() )
	//{
	//	style &= ~WS_SIZEBOX;
	//}

	n_win_style_new( hwnd, style );


	return;
}




#define n_project_pleasewait_on(  h ) n_project_pleasewait( h, n_true  )
#define n_project_pleasewait_off( h ) n_project_pleasewait( h, n_false )

void
n_project_pleasewait( HWND hwnd, int onoff )
{

	static n_posix_char *title = NULL;


	if ( onoff )
	{

		int cch   = n_win_text_cch( hwnd );
		    title = n_string_new( cch );

		n_win_text_get( hwnd, title, cch + 1 );
		n_win_text_set( hwnd, n_project_string_pleasewait );

	} else {

		n_win_text_set( hwnd, title );

		n_string_free( title );
		title = NULL;

	}


	return;
}

void
n_project_defaultbutton( HWND hgui )
{

	// [!] : call at WM_CREATE

	// [!] : not beautiful in classic style

#ifdef _H_NONNON_WIN32_UXTHEME

	n_uxtheme uxtheme;

	n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, hgui, L"BUTTON" );

	if ( uxtheme.onoff )
	{
		n_win_style_add( hgui, BS_DEFPUSHBUTTON );
	}

	n_uxtheme_exit( &uxtheme, hgui );

#endif // #ifndef _H_NONNON_WIN32_UXTHEME


	return;
}

n_bool
n_project_dwm_is_on( void )
{

	// [Patch] : Win10 Technical Preview : DWM window color is borken
	//
	//	build 10130 : caption background will be white
	//	build 10130 : DwmExtendFrameIntoClientArea() works inaccurately
	//	build 10162 : DwmExtendFrameIntoClientArea() works inaccurately
	//	build 10240 : DwmExtendFrameIntoClientArea() works inaccurately
	//	build 14393 : Red Stone 1 : still the same

	return n_win_dwm_aeroglass_is_on();
}




#ifdef _H_NONNON_NEUTRAL_INI


void
n_project_darkmode( void )
{

	n_posix_char *cur_folder = n_string_path_folder_current_new();
	n_win_exedir2curdir();


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_project_ini_name );


	n_posix_char str[ 100 ];
	n_ini_value_str_literal( &ini, "[NonnonWin]", "darkmode", "auto", str , 100 );

	n_win_darkmode();

	if ( n_string_is_same_literal( "auto", str ) )
	{
		//
	} else
	if ( n_string_is_same_literal( "on", str ) )
	{
		n_win_darkmode_onoff = n_true;
	} else
	if ( n_string_is_same_literal( "off", str ) )
	{
		n_win_darkmode_onoff = n_false;
	}


	n_ini_value_str_literal( &ini, "[NonnonWin]", "fluent_ui", "auto", str , 100 );

	n_win_fluent_ui();

	if ( n_string_is_same_literal( "auto", str ) )
	{
		//
	} else
	if ( n_string_is_same_literal( "on", str ) )
	{
		n_win_fluent_ui_onoff = N_WIN_FLUENT_UI_OVERRIDE;
	} else
	if ( n_string_is_same_literal( "off", str ) )
	{
		n_win_fluent_ui_onoff = n_false;
	}


	n_ini_free( &ini );


	n_string_path_folder_change_fast( cur_folder );
	n_string_path_free( cur_folder );


	return;
}


#endif // #ifdef _H_NONNON_NEUTRA_INI




BOOL CALLBACK
n_project_toolband_EnumChildProc( HWND hwnd, LPARAM lparam )
{

	//HDC hdc = (HDC) lparam;


	//s32 x,y,sx,sy; n_win_location( hwnd, &x, &y, &sx, &sy );
	//ExcludeClipRect( (HDC) lparam, x,y,x+sx,y+sy );


	//n_win_message_send( hwnd, WM_PRINTCLIENT, hdc, PRF_OWNED );

	n_win_refresh( hwnd, n_false );


	return TRUE;
}

#define N_PROJECT_TOOLBAND_MODE_PARTIAL ( 0 )
#define N_PROJECT_TOOLBAND_MODE_ALL     ( 1 )

static int n_project_toolband_mode = N_PROJECT_TOOLBAND_MODE_PARTIAL;

void
n_project_toolband_dwm_onoff( HWND hwnd )
{

	if ( n_win_darkmode_onoff ) { return; }

	if ( n_project_toolband_mode == N_PROJECT_TOOLBAND_MODE_PARTIAL )
	{
		s32 ico; n_win_stdsize( hwnd, NULL, &ico, NULL );
		n_win_dwm_transparent_on_partial( hwnd, 1,ico,1,1 );
	} else {
		n_win_dwm_transparent_on( hwnd );
	}

	return;
}

void
n_project_toolband_redraw( HWND hwnd, HWND hgui, HDC hdc, RECT r )
{
//return;

	if ( n_win_darkmode_onoff )
	{

		n_win_box( hgui, hdc, &r, n_win_darkmode_bg );

	} else
	if ( n_sysinfo_version_10_or_later() )
	{

		n_win_box( hgui, hdc, &r, 0 );

	} else
	if ( n_sysinfo_version_8_or_later() )
	{

		n_win_box( hgui, hdc, &r, 0 );

	} else
	if ( n_win_dwm_is_on() )
	{

		n_win_box( hgui, hdc, &r, 0 );

	} else {

		int color_id = COLOR_BTNFACE;

		if ( n_false == n_win_style_is_classic() )
		{
			if ( n_sysinfo_version_vista_or_later() )
			{
				if ( hwnd == GetActiveWindow() )
				{
					color_id = COLOR_GRADIENTACTIVECAPTION;
				} else {
					color_id = COLOR_GRADIENTINACTIVECAPTION;
				}
			}
		}

		n_win_box( hgui, hdc, &r, GetSysColor( color_id ) );

	}


	return;
}

void
n_project_toolband_mouse_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, n_bool sysmenu_onoff )
{

	if (
		( n_win_dwm_is_on() )
		||
		(
			( n_sysinfo_version_vista_or_later() )
			&&
			( n_false == n_win_style_is_classic() )
		)
	)
	{
		//
	} else {
		return;
	}


	switch( msg ) {

/*
	case WM_MOUSEMOVE :
	{

		n_posix_char str_class[ N_WIN_CLASS_CCH ]; n_win_class( n_win_cursor2hwnd_relative( hwnd ), str_class );
n_win_hwndprintf_literal( hwnd, " %s ", str_class );

	}
	break;
*/

	case WM_LBUTTONDOWN :
	{
//n_win_hwndprintf_literal( hwnd, " DOWN " );

		if ( hgui == n_win_cursor2hwnd_relative( hwnd ) )
		{
			POINT pt; GetCursorPos( &pt );
			n_win_message_send( hwnd, WM_NCLBUTTONDOWN, HTCAPTION, &pt );
		}

	}
	break;

	case WM_LBUTTONUP :
	{
//n_win_hwndprintf_literal( hwnd, " UP " );

		if ( hgui == n_win_cursor2hwnd_relative( hwnd ) )
		{
			POINT pt; GetCursorPos( &pt );
			n_win_message_send( hwnd, WM_NCLBUTTONUP, HTCAPTION, &pt );
		}

	}
	break;

	case WM_LBUTTONDBLCLK :
	{
//n_win_hwndprintf_literal( hwnd, " WM_LBUTTONDBLCLK " );

		if ( hgui == n_win_cursor2hwnd_relative( hwnd ) )
		{
			POINT pt; GetCursorPos( &pt );
			n_win_message_send( hwnd, WM_NCLBUTTONDBLCLK, HTCAPTION, &pt );
		}

	}
	break;


	case WM_MBUTTONDBLCLK :
	{
//n_win_hwndprintf_literal( hwnd, " WM_MBUTTONDBLCLK " );

		// [x] : this message is not sent when you use mouse hook

		if ( hgui == n_win_cursor2hwnd_relative( hwnd ) )
		{
			POINT pt; GetCursorPos( &pt );
			n_win_mbutton2centering_proc( hwnd, WM_NCMBUTTONDBLCLK, HTCAPTION, (LPARAM) &pt );
		}

	}
	break;


	case WM_RBUTTONUP :

		if ( sysmenu_onoff )
		{
			if ( hgui == n_win_cursor2hwnd_relative( hwnd ) )
			{

#ifdef _H_NONNON_WIN32_WIN_TITLEMENU

				n_win_titlemenu *p = n_win_titlemenu_target;

				if ( p == NULL ) { break; }

				if ( p->hmenu != NULL )
				{
					n_win_menu_popup_show( p->hmenu, p->hwnd );
				} else
				if ( p->smenu != NULL )
				{
					if ( IsWindow( p->hwnd_menu ) )
					{
						n_win_message_send( p->hwnd_menu, WM_CLOSE, 0, 0 );
					}

					SetActiveWindow( p->hwnd );

					n_win_simplemenu_show( p->smenu, p->hwnd );
				}

				break;

#endif // #ifdef _H_NONNON_WIN32_WIN_TITLEMENU

#ifdef _H_NONNON_WIN32_WIN_MENU

				HMENU hmenu = GetSystemMenu( hwnd, n_false );
				n_win_menu_system_show( hmenu, hwnd );

#endif // #ifdef _H_NONNON_WIN32_WIN_MENU

			}
		}

	break;


	} // switch


	return;
}

void
n_project_toolband_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, n_bool sysmenu_onoff )
{
//return;

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( n_win_dwm_is_on() )
		{
			n_project_toolband_dwm_onoff( hwnd );

			n_win_refresh( hgui, n_false );
			EnumChildWindows( hgui, n_project_toolband_EnumChildProc, (LPARAM) 0 );
		}

	break;

	case WM_ACTIVATE :

		//if ( wparam == WA_INACTIVE ) { break; }

		if ( n_win_dwm_is_on() )
		{
			n_project_toolband_dwm_onoff( hwnd );
			break;
		}

		if ( n_win_style_is_classic() ) { break; }

		if ( n_sysinfo_version_vista_or_later() )
		{
			n_win_refresh( hgui, n_false );
			EnumChildWindows( hgui, n_project_toolband_EnumChildProc, (LPARAM) 0 );
		}

	break;

	case WM_PAINT :

		if ( n_false == IsWindowVisible( hwnd ) ) { break; }

		if ( n_win_dwm_is_on() )
		{
			n_project_toolband_dwm_onoff( hwnd );
			break;
		}

		if ( n_win_style_is_classic() ) { break; }

		if ( n_sysinfo_version_vista_or_later() )
		{
			n_win_refresh( hgui, n_false );
			EnumChildWindows( hgui, n_project_toolband_EnumChildProc, (LPARAM) 0 );
		}

	break;

	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		HDC  hdc = di->hDC;
		RECT r   = di->rcItem;

		n_project_toolband_redraw( hwnd, hgui, hdc, r );

	}
	break;

	} // switch


	n_project_toolband_mouse_proc( hwnd, msg, wparam, lparam, hgui, sysmenu_onoff );


	return;
}




inline int
n_project_n_win_set( void )
{

	// [!] : WS_OVERLAPPEDWINDOW needs this module

	// [x] : Win10 build 10041 : compatibilty is broken
	// [!] : Win10 build 10130 : this problem is fixed

	// [Needed] : VC++ 2017 : N_WIN_SET_CALCONLY is needed
	//
	//	don't use MoveWindow() or SetWindowPos() at WM_SIZE
	//	MinGW does not need this

	return N_WIN_SET_CALCONLY;
}

inline int
n_project_settingchange_interval( void )
{

	if ( n_sysinfo_version_xp_or_later() )
	{
		return 1000;
	}


	return 0;
}

static n_bool n_project_system_icon_color_special_onoff = n_false;

void
n_project_system_icon_color( n_bmp *b, n_bmp *m )
{

	u32 base = n_win_dwm_windowcolor();
	u32 face = n_bmp_black;
	u32 lite = n_bmp_white;
	u32 pink = n_bmp_hue_wheel_tweak_pixel( base, 64 );

	if ( n_win_color_is_highcontrast() )
	{
		if ( RGB( 0,0,0 ) == GetSysColor( COLOR_WINDOW ) )
		{
			face = n_bmp_white;
		}
	}

	n_bmp_flush_replacer( b, n_bmp_rgb( 200,240,255 ), n_bmp_blend_pixel( base, lite, 0.75 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb( 100,220,255 ), n_bmp_blend_pixel( base, lite, 0.50 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb(   0,200,255 ), n_bmp_blend_pixel( base, face, 0.00 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb(   0,150,200 ), n_bmp_blend_pixel( base, face, 0.25 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb(   0,100,150 ), n_bmp_blend_pixel( base, face, 0.50 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb(   0, 50,100 ), n_bmp_blend_pixel( base, face, 0.75 ) );

	if ( n_project_system_icon_color_special_onoff ) { return; }

	n_bmp_flush_replacer( b, n_bmp_rgb( 255,  0,150 ), n_bmp_blend_pixel( pink, face, 0.00 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb( 200,  0,100 ), n_bmp_blend_pixel( pink, face, 0.25 ) );
	n_bmp_flush_replacer( b, n_bmp_rgb( 150,  0, 50 ), n_bmp_blend_pixel( pink, face, 0.50 ) );


	return;
}


#endif // #ifdef _H_NONNON_WIN32_WIN




#define N_PROJECT_SYSTRAY_ID_NONNON_APPLET_CALENDAR 1
#define N_PROJECT_SYSTRAY_ID_NONNON_APPS_CALENDAR   2
#define N_PROJECT_SYSTRAY_ID_MARIE                  3
#define N_PROJECT_SYSTRAY_ID_NMIXER                 4
#define N_PROJECT_SYSTRAY_ID_WHEEL_AXL              5
#define N_PROJECT_SYSTRAY_ID_WHITENOISE             6




#endif // _H_NONNON_PROJECT_MACRO


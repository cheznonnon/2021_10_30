// Nonnon Win32 System Information
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_PROCESS
#define _H_NONNON_WIN32_SYSINFO_PROCESS




#include "../../neutral/posix.c"


#include <psapi.h>
#include <tlhelp32.h>




typedef struct {

	DWORD         pid;
	n_posix_char *name;

} n_sysinfo_process;




BOOL CALLBACK
n_sysinfo_process_pid2hwnd( HWND hwnd, LPARAM lparam )
{

	DWORD *pid = (DWORD*) lparam;
	DWORD dw;


	GetWindowThreadProcessId( hwnd, &dw );
	if ( (*pid) == dw )
	{

		HWND *h = (HWND*) lparam;

		(*h) = hwnd;

		return n_posix_false;
	}


	return n_posix_true;
}

// internal
void
n_sysinfo_process_9x_EnumWindows( PROCESSENTRY32 *p )
{

	n_posix_debug_literal
	(
		"ProcessID    \t: %lu \nDefHeapID    \t: %lu \nModuleID     \t: %lu \nParentProcID \t: %lu",
/*
		"ProcessID    \t: %lu \n"
		"DefHeapID    \t: %lu \n"
		"ModuleID     \t: %lu \n"
		"ParentProcID \t: %lu", 
*/
		p->th32ProcessID,
		p->th32DefaultHeapID,
		p->th32ModuleID,
		p->th32ParentProcessID
	);


	return;
}

void
n_sysinfo_process_9x( WNDENUMPROC callback )
{

#ifdef UNICODE
	n_posix_bool is_chicago = n_posix_false;
#else // #ifdef UNICODE
	n_posix_bool is_chicago = n_posix_true;
#endif // #ifdef UNICODE


	HANDLE hsnapshot = INVALID_HANDLE_VALUE;


	HMODULE hmod = LoadLibrary( n_posix_literal( "kernel32.dll" ) );
	FARPROC func = GetProcAddress( hmod, "CreateToolhelp32Snapshot" );

	if ( func != NULL ) { hsnapshot = (HANDLE) (*func)( TH32CS_SNAPPROCESS, 0 ); }

	if ( hsnapshot == INVALID_HANDLE_VALUE )
	{

		FreeLibrary( hmod );

		return;
	}


	if ( is_chicago )
	{
		func = GetProcAddress( hmod, "Process32First" );
	} else {
		func = GetProcAddress( hmod, "Process32FirstW" );
	}


	if ( func == NULL )
	{

		CloseHandle( hsnapshot );

		FreeLibrary( hmod );

		return;
	}


	// [x] : Win9x needs this

	PROCESSENTRY32 pe32; ZeroMemory( &pe32, sizeof( PROCESSENTRY32 ) );

	while( 1 )
	{

		//PROCESSENTRY32 pe32; ZeroMemory( &pe32, sizeof( PROCESSENTRY32 ) );

		if ( is_chicago )
		{
			pe32.dwSize = sizeof( PROCESSENTRY32  );
		} else {
			pe32.dwSize = sizeof( PROCESSENTRY32W );
		}

		BOOL b = (BOOL) (*func)( hsnapshot, &pe32 );
		if ( b == n_posix_false ) { break; }

//n_sysinfo_process_9x_EnumWindows( pe32 );


		LPARAM lparam = (LPARAM) pe32.th32ProcessID;
		EnumWindows( n_sysinfo_process_pid2hwnd, (LPARAM) &lparam );


		n_sysinfo_process p;

		p.pid  = pe32.th32ProcessID;
		p.name = n_string_carboncopy( pe32.szExeFile );

		(*callback)( (HWND) lparam, (LPARAM) &p );


		if ( is_chicago )
		{
			func = GetProcAddress( hmod, "Process32Next" );
		} else {
			func = GetProcAddress( hmod, "Process32NextW" );
		}

		if ( func == NULL ) { break; }

	}


	CloseHandle( hsnapshot );

	FreeLibrary( hmod );


	return;
}

void
n_sysinfo_process_nt( WNDENUMPROC callback )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "psapi.dll" ) );

	FARPROC n_EnumProcesses      = GetProcAddress( hmod, "EnumProcesses"      );
	FARPROC n_EnumProcessModules = GetProcAddress( hmod, "EnumProcessModules" );
#ifdef UNICODE
	FARPROC n_GetModuleBaseName  = GetProcAddress( hmod, "GetModuleBaseNameW" );
#else  // #ifdef UNICODE
	FARPROC n_GetModuleBaseName  = GetProcAddress( hmod, "GetModuleBaseNameA" );
#endif // #ifdef UNICODE

	if (
		( n_EnumProcesses      == NULL )
		||
		( n_EnumProcessModules == NULL )
		||
		( n_GetModuleBaseName  == NULL )
	)
	{
		FreeLibrary( hmod );
		return;
	}


	n_posix_bool ret = n_posix_false;


	// [x] : length is unknown

	DWORD  count_1 = 1;
	DWORD  count_2 = count_1 + 1;
	DWORD    b_i_1 = count_1 * sizeof( DWORD );
	DWORD    b_i_2 = count_2 * sizeof( DWORD );
	DWORD    b_o_1 = 0;
	DWORD    b_o_2 = 0;
	DWORD  *proc_1 = n_memory_new( b_i_1 );
	DWORD  *proc_2 = n_memory_new( b_i_2 );
	while( 1 )
	{//break;

		ret |= n_EnumProcesses( proc_1, b_i_1, &b_o_1 );
		ret |= n_EnumProcesses( proc_2, b_i_2, &b_o_2 );

		if ( ret == n_posix_false ) { break; }

		if ( b_o_1 == b_o_2 ) { break; }

		n_memory_free( proc_1 );
		n_memory_free( proc_2 );

		count_1 = count_1 + 1;
		count_2 = count_1 + 1;
		  b_i_1 = count_1 * sizeof( DWORD );
		  b_i_2 = count_2 * sizeof( DWORD );
		  b_o_1 = 0;
		  b_o_2 = 0;
		 proc_1 = n_memory_new( b_i_1 );
		 proc_2 = n_memory_new( b_i_2 );

	}


	DWORD count = b_o_1 / sizeof( DWORD );
//n_posix_debug_literal( " %d ", count );

	if ( ( ret == n_posix_false )||( count == 0 ) )
	{
		n_memory_free( proc_1 );
		n_memory_free( proc_2 );

		FreeLibrary( hmod );
		return;
	}


	DWORD i = 0;
	while( 1 )
	{//break;

		HANDLE h = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, n_posix_false, proc_1[ i ] );
		if ( h != NULL )
		{

			HMODULE proc_hmod;
			DWORD   proc_cb;

			if ( n_EnumProcessModules( h, &proc_hmod, sizeof( HMODULE ), &proc_cb ) )
			{

				LPARAM lparam = (LPARAM) proc_1[ i ];
				EnumWindows( n_sysinfo_process_pid2hwnd, (LPARAM) &lparam );


				n_sysinfo_process p;

				p.pid = proc_1[ i ];


				n_posix_bool ret = n_posix_false;

				// [x] : cch is unknown

				DWORD          cch_1 = 8 + 1 + 3;
				DWORD          cch_2 = cch_1 + 1;
				n_posix_char *name_1 = n_string_new( cch_1 );
				n_posix_char *name_2 = n_string_new( cch_2 );

				while( 1 )
				{

					DWORD dw1 = n_GetModuleBaseName( h, proc_hmod, name_1, cch_1 );
					DWORD dw2 = n_GetModuleBaseName( h, proc_hmod, name_2, cch_2 );
					if ( ( dw1 == 0 )||( dw2 == 0 ) ) { ret = n_posix_true; break; }

					if ( n_string_is_same( name_1, name_2 ) ) { break; }

					n_string_free( name_1 );
					n_string_free( name_2 );

					 cch_1 = cch_1 + 1;
					 cch_2 = cch_1 + 1;
					name_1 = n_string_new( cch_1 );
					name_2 = n_string_new( cch_2 );

				}

				if ( ret == n_posix_false )
				{
					p.name = name_1;
					(*callback)( (HWND) lparam, (LPARAM) &p );
				} else {
					n_string_free( name_1 );
				}

				n_string_free( name_2 );

//n_posix_debug_literal( "%s", name_1 );
			}

		}
		CloseHandle( h );


		i++;
		if ( i >= count ) { break; }
	}


	n_memory_free( proc_1 );
	n_memory_free( proc_2 );


	FreeLibrary( hmod );


	return;
}

void
n_sysinfo_process_main( WNDENUMPROC callback )
{
//n_sysinfo_process_nt( callback ); return;

	if ( n_sysinfo_version_9x() )
	{

		n_sysinfo_process_9x( callback );

	} else {

		if ( n_sysinfo_version_2000_or_later() )
		{
			n_sysinfo_process_9x( callback );
		} else {
			n_sysinfo_process_nt( callback );
		}

	}


	return;
}


#endif // _H_NONNON_WIN32_SYSINFO_PROCESS

